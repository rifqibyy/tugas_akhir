        <?php include('header.php') ?>

        <?php include('sidebar.php') ?>

        <div id="content-wrapper">

            <div class="container-fluid">

                <!-- Breadcrumbs-->
                <?php include('breadcumb.php') ?>

                <!-- Core Content -->
                <div id="core-content"></div>

            </div>
            <!-- /.container-fluid -->

            <!-- Sticky Footer -->
            <?php include('sticky-footer.php') ?>

        </div>
        <!-- /.content-wrapper -->

        <?php include('footer.php')?>

